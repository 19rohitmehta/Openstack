#!/bin/bash


ansible-playbook GP-computesMedia.yaml | tee GP-computesMedialog
ansible-playbook GP-director.yaml | tee GP-directorlog
ansible-playbook GP-controllers.yaml | tee GP-controllerslog
ansible-playbook GP-computesSignalling.yaml | tee GP-computesSignallinglog
