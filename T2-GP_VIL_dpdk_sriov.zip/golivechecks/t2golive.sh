#!/bin/bash

ansible-playbook golive-director.yaml | tee -a t2-directorlogs
ansible-playbook golive-controllers.yaml | tee -a t2-controllerlogs
#ansible-playbook golive-computesSignalling.yaml | tee -a t2-cmputeslogsSignalling
ansible-playbook golive-computesMedia.yaml | tee -a t2-cmputeslogsMedia
ansible-playbook golive-computesSRIOV.yaml | tee -a t2-cmputeslogsSRIOV
ansible-playbook golive-storage.yaml | tee -a t2-storagelogs
#ansible-playbook golive-idrac.yaml  | tee -a t2-idraclogs
